import java.io.FileNotFoundException;

public class Main {

    public static void main(String[] args) throws FileNotFoundException {
	Hash test1 = new Hash();



	System.out.println(test1.createHash("C:\\Users\\Isaia\\Documents\\School\\CSCI 1933\\Projects\\Project 3\\src\\that_bad.txt"));
    }
}