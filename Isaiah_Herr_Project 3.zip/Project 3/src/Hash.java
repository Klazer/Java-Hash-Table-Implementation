import java.util.*;
import java.io.*;

public class Hash {
    LinkedList[] Mainarray;
    int size;

    public Hash(int size) { //Constructor with defined values
        this.Mainarray = new LinkedList[size];
        this.size = size;
    }

    public Hash() { //Constructor with default values
        this.Mainarray = new LinkedList[150];
        this.size = 150;
    }

    public LinkedList[] createHash(String filename){
        File file = new File(filename);

        Scanner readFile = null;
        Scanner readFile2 = null;


        try { //Our try and catch block
            readFile = new Scanner(file);
            readFile2 = new Scanner(file);
        } catch (FileNotFoundException e) {
            System.out.println(file + " has not been found");
        }

        System.out.println("Connection to file: " + file + " successful");
        System.out.println();

        while (readFile.hasNext()) { //Iterates through each token on text file
            String tokens = readFile.next();
            int index = Math.floorMod(tokens.hashCode(), Mainarray.length);
            //System.out.println(index);
            LinkedList<String> chain = new LinkedList<String>(); //Linked list containing tokens of the same index

            if (Mainarray[index] == null) { //These next lines of code will attempt to implement the chaining method.
                while (readFile2.hasNext()) { //Iterates through each token on the text file
                    String tokens2 = readFile2.next();
                    int index2 = Math.floorMod(tokens2.hashCode(), Mainarray.length);

                    if (index2 == index) { //Checks to see if indexes of other tokens are the same and if the element array is empty. If they are, we add a token to the linkedlist element.
                        chain.add(tokens2);
                    }
                }
            }
            Mainarray[index] = chain;
        }
        for (int x = 0; x < Mainarray.length; x++){
            System.out.println(Mainarray[x]);
        }
        return Mainarray;
    }
}
