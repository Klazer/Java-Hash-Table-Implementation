import java.util.*;
import java.io.*;

public class Hash {
    LinkedList[] Mainarray;
    int size;
    String[] alltoken;

    public Hash() { //Constructor with default values
        this.Mainarray = new LinkedList[123];
    }

    public Hash(int size) {
        this.Mainarray = new LinkedList[size];
    }

    public LinkedList[] createHash() {
        System.out.println("Please enter in the filepath for your txt file");
        Scanner part1 = new Scanner(System.in);
        String filename = part1.nextLine();


        File file = new File(filename);

        Scanner readFile = null;
        Scanner readFile2 = null;
        int count = 0;
        int count2 = 0;


        try { //Our try and catch block
            readFile = new Scanner(file);
            readFile2 = new Scanner(file);
        } catch (FileNotFoundException e) {
            System.out.println(file + " has not been found");
        }

        System.out.println("Connection to file: " + file + " successful");
        System.out.println();

        while (readFile.hasNext()) {
            String s = readFile.next();
            //System.out.println("Token found: " + s.hashCode());
            count++;
        }
        alltoken = new String[count];

        while (readFile2.hasNext()) { //Adds all tokens into an array
            String s = readFile2.next();
            alltoken[count2] = s;
            count2++;
        }

        for (int x = 0; x < alltoken.length; x++) {
            int index = Math.floorMod(alltoken[x].hashCode(), Mainarray.length);
            LinkedList<String> chain = new LinkedList<String>(); //Linked list containing tokens of the same index

            if (Mainarray[index] == null) { //These next lines of code will attempt to implement the chaining method.
                for (int y = 0; y < alltoken.length; y++) { //Iterates through each token on the text file
                    int index2 = Math.floorMod(alltoken[y].hashCode(), Mainarray.length);

                    if (index2 == index && !chain.contains(alltoken[y])) { //Checks to see if indexes of other tokens are the same and if the element array is empty. If they are, we add a token to the linkedlist element.
                        chain.add(alltoken[y]);                             //Also doesn't add the token if it already exists in the linked list.
                    }
                }
                Mainarray[index] = chain;
            }
        }
        //for (int z = 0; z < Mainarray.length; z++){
        //System.out.println(Mainarray[z]);
        //}

        return Mainarray;
    }

    public void display() {
        for (int z = 0; z < Mainarray.length; z++) {
            if (Mainarray[z] == null) {
                System.out.println("Index " + (z + 1) + ": " + Mainarray[z] + ", Number of keys: " + 0);
            } else {
                System.out.println("Index " + (z + 1) + ": " + Mainarray[z] + ", Number of keys: " + Mainarray[z].size());
            }
        }
    }

    public int getKey(String token) { //Will return a numeric value representation of a word
        int charvalue = 0;
        for (int x = 0; x < token.length(); x++) {
            charvalue += token.charAt(x) * 10; //Goes through each character in a list, multiplies value by 10, and then adds it to charvalue.
        }
        return charvalue;
    }

    public int getKey2(String token) { //Will return a numeric value representation of a word
        int charvalue = 0;
        int count = 0;
        for (int x = 0; x < token.length(); x++) {
            charvalue += token.charAt(x) * 31 * alltoken[x].length() - count; //Goes through each character in a list, multiplies value by 10, and then adds it to charvalue.
            count++;
        }
        return charvalue;
    }
        public int hashfunc1 ( int key){ //This will be our first hash function in our double hash implementation.
            int hashval = key % Mainarray.length;
            if (hashval < 0) {
                hashval += Mainarray.length;
            }
            return hashval;
        }

        public int hashfunc2 ( int key)
        { //Will be our step function in our hash implementation. We want to use only prime numbers to create more "uniqueness" for each token.
            int hashval = key % Mainarray.length;
            if (hashval < 0) { //If hashval becomes negative, we continually add the length of the array until the number becomes positive
                hashval += Mainarray.length;
            }
            return 7 - hashval % 7; //This is what will differentiate our step function in our double hash.
        }


        public void distribute ()
        { //This will iterate through the hash table and try to distribute tokens evenly across the hash table with each index containing a maximum of 3 tokens.
            for (int x = 0; x < alltoken.length; x++) {
                LinkedList<String> chain = new LinkedList<String>(); //Linked list that will chain tokens that consist of the index. Used for collisions.

                int hashval = hashfunc1(getKey(alltoken[x]));
                int step = hashfunc2(getKey(alltoken[x]));

                //while (Mainarray[hashval] != null){
                hashval += step + 3;
                hashval = hashval % Mainarray.length;
                //}

                chain.add(alltoken[x]); //Add the token into the chain
                Mainarray[hashval] = chain; //Add the linked list into the index that hashval calculated.
            }
        }


    public void specificHash() {
        for (int x = 0; x < alltoken.length; x++) {
            int hashval = getKey(alltoken[x]); //Receive the numeric value for tokens
            LinkedList<String> chain = new LinkedList<String>(); //Linked list that will chain tokens that consist of the index. Used for collisions.

            int step = hashfunc2(getKey2(alltoken[x]));
            hashval += step * 31 + 215 * x; //This is our specific hash function
            hashval = hashval % Mainarray.length;
            //}

            chain.add(alltoken[x]); //Add the token into the chain and add
            Mainarray[hashval] = chain; //Add the linked list into the index that hashval calculated.
        }
    }
}
