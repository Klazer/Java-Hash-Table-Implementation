import java.io.FileNotFoundException;

public class Main {

	public static void main(String[] args) throws FileNotFoundException {
		Hash test1 = new Hash();

		//test1.createHash();
		//test1.display();
		//test1.distribute(); //Used for part 4 of the project
		System.out.println("============");
		//test1.display();

	Hash test2 = new Hash(77);
	test2.createHash();
	test2.specificHash();
	test2.display();
    }


	}
