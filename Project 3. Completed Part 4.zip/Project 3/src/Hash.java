import java.util.*;
import java.io.*;

public class Hash {
    LinkedList[] Mainarray;
    int size;

    public Hash(int size) { //Constructor with defined values
        this.Mainarray = new LinkedList[size];
        this.size = size;
    }

    public Hash() { //Constructor with default values
        this.Mainarray = new LinkedList[150];
        this.size = 150;
    }

    public LinkedList[] createHash(String filename) {
        File file = new File(filename);

        Scanner readFile = null;
        Scanner readFile2 = null;
        int count = 0;
        int count2 = 0;


        try { //Our try and catch block
            readFile = new Scanner(file);
            readFile2 = new Scanner(file);
        } catch (FileNotFoundException e) {
            System.out.println(file + " has not been found");
        }

        System.out.println("Connection to file: " + file + " successful");
        System.out.println();

        while (readFile.hasNext()) {
            String s = readFile.next();
            //System.out.println("Token found: " + s.hashCode());
            count++;
        }
        String[] alltoken = new String[count];

        while (readFile2.hasNext()) { //Adds all tokens into an array
            String s = readFile2.next();
            alltoken[count2] = s;
            count2++;
        }

        for (int x = 0; x < alltoken.length; x++) {
            int index = Math.floorMod(alltoken[x].hashCode(), Mainarray.length);
            LinkedList<String> chain = new LinkedList<String>(); //Linked list containing tokens of the same index

            if (Mainarray[index] == null) { //These next lines of code will attempt to implement the chaining method.
                for (int y = 0; y < alltoken.length; y++) { //Iterates through each token on the text file
                    int index2 = Math.floorMod(alltoken[y].hashCode(), Mainarray.length);

                    if (index2 == index && !chain.contains(alltoken[y])) { //Checks to see if indexes of other tokens are the same and if the element array is empty. If they are, we add a token to the linkedlist element.
                        chain.add(alltoken[y]);                             //Also doesn't add the token if it already exists in the linked list.
                    }
                }
                Mainarray[index] = chain;
            }
        }
        //for (int z = 0; z < Mainarray.length; z++){
        //System.out.println(Mainarray[z]);
        //}

        return Mainarray;
    }

    public void display() {
        for (int z = 0; z < Mainarray.length; z++) {
            //System.out.println("Index " + (z + 1) + ": " + Mainarray[z]);
            if (Mainarray[z] == null) {
                System.out.println("Index " + (z + 1) + ": " + Mainarray[z] + ", Number of keys: " + 0);
            } else {
                System.out.println("Index " + (z + 1) + ": " + Mainarray[z] + ", Number of keys: " + Mainarray[z].size());
            }
        }
    }

    public void distribute() { //This will iterate through the hash table and try to distribute tokens evenly across the hash table with each index containing a minimum of 3 tokens.
        for (int x = 0; x < Mainarray.length; x++) {
            if (Mainarray[x] == null) { //If the index contains null, do nothing
            }
            else if (Mainarray[x].size() > 3) {
                for (int y = 0; y < Mainarray.length; y++) { //Iterates through the hash table again to see if there are any indexes with a size less than
                    if (Mainarray[y] == null) { //If index contains null, we can create a new linkedlist and add elements here until we have 3 keys
                        LinkedList<Object> chain = new LinkedList<Object>();
                        while (chain.size() <= 3 && Mainarray[x].size() > 3) {
                            chain.add(Mainarray[x].get(0));
                            Mainarray[x].remove(0);
                            Mainarray[y] = chain;
                        }
                    }
                    else if (Mainarray[y].size() < 3 && Mainarray[x].size() > 3) { //Adds elements to element at y index if there is room.
                        Mainarray[y].add(Mainarray[x].get(0));
                        Mainarray[x].remove(0);
                    }
                }
            }
        }
    }
}